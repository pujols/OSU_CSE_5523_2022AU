py -3 dnn_cnn_2.py --alpha 0.9

python3 dnn_cnn.py
